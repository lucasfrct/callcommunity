<?php
namespace TotalVoice;

/**
 * RouteInterface
 */
interface RouteInterface
{
    /**
     * return string
     */
    public function build();
}