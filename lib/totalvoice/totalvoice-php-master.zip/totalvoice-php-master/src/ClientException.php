<?php
namespace TotalVoice;

class ClientException extends \Exception {}